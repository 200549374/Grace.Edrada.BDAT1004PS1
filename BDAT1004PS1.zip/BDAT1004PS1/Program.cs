﻿
// Write and Evaluate C# expressions

// a. How many letters are there in 'Supercalifragilisticexpialidocious'?
string inputString = "Supercalifragilisticexpialidocious";
int letterCount = inputString.Count(char.IsLetter);
Console.WriteLine("Number of Letters: " + letterCount);

// b. Does 'Supercalifragilisticexpialidocious' contain 'ice' as a substring?
static void Main()
{
    string mainString = "Supercalifragilisticexpialidocious";
    string subString = "ice";

    bool containsIce = mainString.Contains(subString);

    if (containsIce)
    {
        Console.WriteLine("The string contains 'ice'.");
    }
    else
    {
        Console.WriteLine("The string does not contain 'ice'.");
    }

}

// c. Which of the following words is the longest: Supercalifragilisticexpialidocious, Honorificabilitudinitatibus, or Bababadalgharaghtakamminarronnkonn?

namespace charcount
{
    class Program
    {
        static void WordLength()
        {
            string word1 = "Supercalifragilisticexpialidocious";
            string word2 = "Honorificabilitudinitatibus";
            string word3 = "Bababadalgharaghtakamminarronnkonn";

            string longestWord = FindLongestWord(word1, word2, word3);

            Console.WriteLine($"The longest word is: {longestWord}");
        }

        static string FindLongestWord(params string[] words)
        {
            string longest = string.Empty;

            foreach (string word in words)
            {
                if (word.Length > longest.Length)
                {
                    longest = word;
                }
            }

            return longest;
        }
    }

}


// 4. Which composer comes first in the dictionary: 'Berlioz', 'Borodin', 'Brian', 'Bartok', 'Bellini', 'Buxtehude', 'Bernstein'. Which one comes last?

class Program
{
    static void Composer()
    {
        string[] composers = { "Berlioz", "Borodin", "Brian", "Bartok", "Bellini", "Buxtehude", "Bernstein" };

        Array.Sort(composers);

        string firstComposer = composers[0];
        string lastComposer = composers[composers.Length - 1];

        Console.WriteLine($"First composer: {firstComposer}");
        Console.WriteLine($"Last composer: {lastComposer}");
    }
}
